Notes: 
If you get a maxium execution error, then you need to extended that allowed execution time in php.ini

php 5.2 seems to have some issues with the current build of wordpress(2.2.2)
you may need to modify the wordpress source code to get php 5.2 to work. There is a ticket for this item